owncloud-files_latexeditor (1.0.0)
* First release
